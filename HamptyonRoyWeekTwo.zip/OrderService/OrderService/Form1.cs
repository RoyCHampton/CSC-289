﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace OrderService
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /**
             * In this block of the code I get the txt file that was located
             * in the computer so I get the information in to the computer
             * Before the user can get to this button they have to answer a 
             * question if the order is 10 dollars or more
             * If the order isnt 10 dollars or more than the user
             * will be prompted that we need orders 10 dollars or more.
             */ 
            string[] item = File.ReadAllLines("orders.txt");
            string output = item[1].ToString().ToLower();
            foreach (var lines in item)
            {
                orderListBox.Items.Add(lines);
            }
                if (output.Contains("food"))
                {
                    string line = File.ReadAllText("orders.txt");
                    string orderLine = line.Split('$').Last();

                    try
                    {
                        double bringIt, ccSalesTax, ncSalesTax;
                        double total = Double.Parse(orderLine);
                        bool val = total >= 10; 
                        
                        /**
                         * This line of the code is to check and see if the total is over 10
                         * dollars
                         */
                        if(val == true)
                        {
                            ncSalesTax = total * .0475;
                            ccSalesTax = total * .0225;
                            bringIt = total * .2;
                            total = total * .2 + total;
                            total += total * .07;
                            double done = System.Math.Round(total, 2);
                            MessageBox.Show("The total for this item for the customer " + done);
                            MessageBox.Show("The NC Sales tax is " + System.Math.Round(ncSalesTax, 3));
                            MessageBox.Show("The Cumberland County Sales tax is " + System.Math.Round(ccSalesTax, 3));
                            MessageBox.Show("The BringIt charge is " + System.Math.Round(bringIt, 3));
                        }
                        else
                        {
                            MessageBox.Show("This order needs to be over 10 dollars");
                        }


                    }
                    catch
                    {
                        MessageBox.Show("Check to make sure that the Price of the the item is in the"
                                      + "in the last line of the txt file");
                    }
                }
                else if(output.Contains("retail"))
                {
                    string line = File.ReadAllText("orders.txt");
                    string orderLine = line.Split('$').Last();

                    try
                    {
                        double bringIt, ccSalesTax, ncSalesTax;
                        double total = Double.Parse(orderLine);
                        bool val = total >= 10;

                        /**
                         * This line of the code is to check and see if the total is over 10
                         * dollars
                         */
                        if (val == true)
                        {
                            ncSalesTax = total * .0475;
                            ccSalesTax = total * .0225;
                            bringIt = total * .05;
                            total = total * .05 + total;
                            total += total * .07;
                            double done = System.Math.Round(total, 2);
                            MessageBox.Show("The total for this item for the customer " + done);
                            MessageBox.Show("The NC Sales tax is " + System.Math.Round(ncSalesTax, 3));
                            MessageBox.Show("The Cumberland County Sales tax is " + System.Math.Round(ccSalesTax, 3));
                            MessageBox.Show("The BringIt charge is " + System.Math.Round(bringIt, 3));
                        }
                        else
                        {
                            MessageBox.Show("This order needs to be over 10 dollars");
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Check to make sure that the Price of the the item is in the"
                                      + "in the last line of the txt file");
                    }
                }
                else
                {
                    MessageBox.Show("Check the formatting for the txt file");
                }            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //This makes the button visbale 
            loadOrderButton.Enabled = true;
            loadOrderButton.Visible = true;
            yesButton.Enabled = false;
            yesButton.Visible = false;
            noButton.Enabled = false;
            noButton.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //This tells the employee that the order isnt over 10 dollars;
            MessageBox.Show("Ensure that the order is over 10 dollars");
        }
    }
}
